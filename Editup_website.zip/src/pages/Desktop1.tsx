import { FunctionComponent, useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./Desktop1.module.css";

const Desktop1: FunctionComponent = () => {
  const navigate = useNavigate();

  const onAboutButtonClick = useCallback(() => {
    navigate("/desktop-6");
  }, [navigate]);

  const onContactButtonClick = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onYtLinkClick = useCallback(() => {
    window.open("https://www.youtube.com/channel/UCqExCUTnlygD2cq_5V4rQhQ");
  }, []);

  const onMohitkumaraptdgmailcomLinkClick = useCallback(() => {
    window.location.href =
      "mailto:mohitkumaraptd@gmail.com?subject=Raising a query / Placing an order";
  }, []);

  const onLinkedinClick = useCallback(() => {
    window.open("https://www.linkedin.com/in/mohit-mehta-391a4b233/");
  }, []);

  const onCheckOutButtonClick = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onCheckOutButton1Click = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onCheckOutButton2Click = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onAboutButton1Click = useCallback(() => {
    navigate("/desktop-6");
  }, [navigate]);

  const onPlaceOrderButtonClick = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onBrowseButtonClick = useCallback(() => {
    navigate("/desktop-5");
  }, [navigate]);

  const onOurWorkButtonClick = useCallback(() => {
    window.open(
      "https://drive.google.com/drive/folders/1noynemnkABw6sgfNXm8dCJLxwg2o97Q6?usp=sharing"
    );
  }, []);

  const onContactButton1Click = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onEmailLinkClick = useCallback(() => {
    window.location.href =
      "mailto:mohitkumaraptd@gmail.com?subject=Placing Order";
  }, []);

  const onLinkedin1Click = useCallback(() => {
    window.location.href = "https://www.linkedin.com/in/mohit-mehta-391a4b233/";
  }, []);

  const onYoutubeLinkClick = useCallback(() => {
    window.open("https://www.youtube.com/@EditupMohitMehta/featured");
  }, []);

  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add(styles.animate);
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  return (
    <div className={styles.desktop1}>
      <div className={styles.rectangleDiv} />
      <div className={styles.editupDiv}>Editup</div>
      <button
        className={styles.aboutButton}
        onClick={onAboutButtonClick}
        data-animate-on-scroll
      >
        About
      </button>
      <button
        className={styles.contactButton}
        onClick={onContactButtonClick}
        data-animate-on-scroll
      >
        Contact
      </button>
      <img className={styles.ellipseIcon} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon1} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon2} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon3} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon4} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon5} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon6} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon7} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon8} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon9} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon10} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon11} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon12} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon13} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon14} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon15} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon16} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon17} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon18} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon19} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon20} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon21} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon22} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon23} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon24} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon25} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon26} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon27} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon28} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon29} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon30} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon31} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon32} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon33} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon34} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon35} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon36} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon37} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon38} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon39} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon40} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon41} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon42} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon43} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon44} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon45} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon46} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon47} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon48} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon49} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon50} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon51} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon52} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon53} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon54} alt="" src="../ellipse-1.svg" />
      <img className={styles.ellipseIcon55} alt="" src="../ellipse-1.svg" />
      <div className={styles.rectangleDiv1} />
      <img className={styles.instaIcon} alt="" src="../insta@2x.png" />
      <a
        className={styles.ytA}
        target="_blank"
        onClick={onYtLinkClick}
        data-animate-on-scroll
      >
        <img className={styles.ytIcon} alt="" src="../yt@2x.png" />
      </a>
      <div className={styles.theMostTrustablePlatformFo}>
        The most trustable platform for all your editing needs .
      </div>
      <div className={styles.wannaMakeAwesomeMotionGrap}>
        <p
          className={styles.wannaMakeAwesome}
        >{`Wanna make awesome motion graphics , `}</p>
        <p className={styles.introsWereHere}>intros. We’re here .</p>
      </div>
      <div className={styles.videosShortsAndReelsThat}>
        <p className={styles.wannaMakeAwesome}>
          Videos , shorts and reels that are impossible
        </p>
        <p className={styles.introsWereHere}>to ignore</p>
      </div>
      <div className={styles.postersThumbnailsCardsA}>
        <p
          className={styles.wannaMakeAwesome}
        >{`Posters , thumbnails , Cards and a lot `}</p>
        <p className={styles.introsWereHere}>more we design .</p>
      </div>
      <a
        className={styles.mohitkumaraptdgmailcom}
        onClick={onMohitkumaraptdgmailcomLinkClick}
      >
        <p className={styles.wannaMakeAwesome}>{` `}</p>
        <p className={styles.introsWereHere}> mohitkumaraptd@gmail.com</p>
      </a>
      <a
        className={styles.linkedinA}
        target="_blank"
        onClick={onLinkedinClick}
        data-animate-on-scroll
      />
      <img className={styles.linkedinIcon} alt="" src="../linkedin1@2x.png" />
      <img className={styles.ae1Icon} alt="" src="../ae-1@2x.png" />
      <div className={styles.ae2Div} />
      <div className={styles.rectangleDiv2} />
      <div className={styles.rectangleDiv3} />
      <div className={styles.rectangleDiv4} />
      <button
        className={styles.checkOutButton}
        onClick={onCheckOutButtonClick}
        data-animate-on-scroll
      >
        Check out
      </button>
      <button
        className={styles.checkOutButton1}
        onClick={onCheckOutButton1Click}
        data-animate-on-scroll
      >
        Check out
      </button>
      <button
        className={styles.checkOutButton2}
        onClick={onCheckOutButton2Click}
        data-animate-on-scroll
      >
        Check out
      </button>
      <img className={styles.ps1Icon} alt="" src="../ps-1@2x.png" />
      <img className={styles.pr1Icon} alt="" src="../pr-1@2x.png" />
      <img className={styles.lineIcon} alt="" src="../line-1.svg" />
      <img className={styles.lineIcon1} alt="" src="../line-1.svg" />
      <img className={styles.lineIcon2} alt="" src="../line-1.svg" />
      <img className={styles.rectangleIcon} alt="" src="../rectangle-7.svg" />
      <img className={styles.vectorIcon} alt="" src="../vector-1.svg" />
      <img className={styles.polygonIcon} alt="" src="../polygon-1.svg" />
      <div className={styles.lineDiv} />
      <div className={styles.lineDiv1} />
      <div className={styles.lineDiv2} />
      <div className={styles.lineDiv3} />
      <div className={styles.lineDiv4} />
      <div className={styles.lineDiv5} />
      <div className={styles.lineDiv6} />
      <div className={styles.lineDiv7} />
      <div className={styles.lineDiv8} />
      <div className={styles.lineDiv9} />
      <div className={styles.lineDiv10} />
      <div className={styles.lineDiv11} />
      <div className={styles.lineDiv12} />
      <div className={styles.lineDiv13} />
      <div className={styles.lineDiv14} />
      <img className={styles.ellipseIcon56} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon57} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon58} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon59} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon60} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon61} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon62} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon63} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon64} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon65} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon66} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon67} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon68} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon69} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon70} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon71} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon72} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon73} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon74} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon75} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon76} alt="" src="../ellipse-57.svg" />
      <img className={styles.rectangleIcon1} alt="" src="../rectangle-8.svg" />
      <button className={styles.homeButton}>Home</button>
      <button className={styles.aboutButton1} onClick={onAboutButton1Click}>
        About
      </button>
      <button
        className={styles.placeOrderButton}
        onClick={onPlaceOrderButtonClick}
      >
        Place order
      </button>
      <button className={styles.browseButton} onClick={onBrowseButtonClick}>
        Browse
      </button>
      <button className={styles.ourWorkButton} onClick={onOurWorkButtonClick}>
        Our Work
      </button>
      <button
        className={styles.contactButton1}
        onClick={onContactButton1Click}
      >{`Contact `}</button>
      <a className={styles.email} onClick={onEmailLinkClick}>
        Email
      </a>
      <a className={styles.linkedinA1} onClick={onLinkedin1Click}>
        linkedin
      </a>
      <a className={styles.youtubeA} onClick={onYoutubeLinkClick}>
        Youtube
      </a>
      <img className={styles.vectorIcon1} alt="" src="../vector-3.svg" />
      <img className={styles.maskGroupIcon} alt="" src="../mask-group@2x.png" />
      <img
        className={styles.maskGroupIcon1}
        alt=""
        src="../mask-group@2x.png"
      />
      <img
        className={styles.maskGroupIcon2}
        alt=""
        src="../mask-group@2x.png"
      />
      <div className={styles.sliceDiv} />
      <b className={styles.motionGraphicsDesigning}>
        Motion Graphics Designing
      </b>
      <img className={styles.image3Icon} alt="" src="../image-3@2x.png" />
      <img className={styles.ellipseIcon77} alt="" src="../ellipse-83.svg" />
      <div className={styles.initiallyStartedAsAYoutube}>
        <p
          className={styles.wannaMakeAwesome}
        >{`Initially started as a youtube channel , Editup aims to cater to `}</p>
        <p className={styles.wannaMakeAwesome}>
          brands in building their social presence at most affordable prices.
        </p>
        <p className={styles.wannaMakeAwesome}>&nbsp;</p>
        <p
          className={styles.wannaMakeAwesome}
        >{`What differentiates us from our competitors is to deliver the project `}</p>
        <p className={styles.wannaMakeAwesome}>
          timely and with least convenience to our clients .
        </p>
        <p
          className={styles.wannaMakeAwesome}
        >{`Mohit Mehta , the founder of this channel , is a 17 year old boy `}</p>
        <p className={styles.wannaMakeAwesome}>
          who is currently pursuing his XII standard from Golaya Progressive
        </p>
        <p className={styles.introsWereHere}>Public School , Palwal .</p>
      </div>
      <b className={styles.aboutUs}>About us</b>
    </div>
  );
};

export default Desktop1;
