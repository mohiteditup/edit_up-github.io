import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./Desktop6.module.css";

const Desktop6: FunctionComponent = () => {
  const navigate = useNavigate();

  const onAboutButtonClick = useCallback(() => {
    navigate("/desktop-6");
  }, [navigate]);

  const onPlaceOrderButtonClick = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onBrowseButtonClick = useCallback(() => {
    navigate("/desktop-5");
  }, [navigate]);

  const onOurWorkButtonClick = useCallback(() => {
    window.open(
      "https://drive.google.com/drive/folders/1noynemnkABw6sgfNXm8dCJLxwg2o97Q6?usp=sharing"
    );
  }, []);

  const onContactButtonClick = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onEmailLinkClick = useCallback(() => {
    window.location.href =
      "mailto:mohitkumaraptd@gmail.com?subject=Placing Order";
  }, []);

  const onLinkedinClick = useCallback(() => {
    window.location.href = "https://www.linkedin.com/in/mohit-mehta-391a4b233/";
  }, []);

  const onYoutubeLinkClick = useCallback(() => {
    window.open("https://www.youtube.com/@EditupMohitMehta/featured");
  }, []);

  return (
    <div className={styles.desktop6}>
      <div className={styles.editupDiv}>Editup</div>
      <div className={styles.contactDiv}>Contact</div>
      <div className={styles.lineDiv} />
      <div className={styles.lineDiv1} />
      <div className={styles.lineDiv2} />
      <div className={styles.lineDiv3} />
      <div className={styles.lineDiv4} />
      <img className={styles.ellipseIcon} alt="" />
      <img className={styles.ellipseIcon1} alt="" />
      <img className={styles.ellipseIcon2} alt="" />
      <img className={styles.ellipseIcon3} alt="" />
      <img className={styles.ellipseIcon4} alt="" />
      <img className={styles.ellipseIcon5} alt="" />
      <img className={styles.ellipseIcon6} alt="" />
      <img className={styles.maskGroupIcon} alt="" src="../mask-group@2x.png" />
      <div className={styles.initiallyStartedAsAYoutube}>
        <p
          className={styles.initiallyStartedAs}
        >{`Initially started as a youtube channel , Editup aims to cater to `}</p>
        <p className={styles.initiallyStartedAs}>
          brands in building their social presence at most affordable prices.
        </p>
        <p className={styles.initiallyStartedAs}>&nbsp;</p>
        <p
          className={styles.initiallyStartedAs}
        >{`What differentiates us from our competitors is to deliver the project `}</p>
        <p className={styles.initiallyStartedAs}>
          timely and with least convenience to our clients .
        </p>
        <p
          className={styles.initiallyStartedAs}
        >{`Mohit Mehta , the founder of this channel , is a 17 year old boy `}</p>
        <p className={styles.initiallyStartedAs}>
          who is currently pursuing his XII standard from Golaya Progressive
        </p>
        <p className={styles.publicSchool}>Public School , Palwal .</p>
      </div>
      <b className={styles.aboutUs}>About us</b>
      <button className={styles.homeButton}>Home</button>
      <button className={styles.aboutButton} onClick={onAboutButtonClick}>
        About
      </button>
      <button
        className={styles.placeOrderButton}
        onClick={onPlaceOrderButtonClick}
      >
        Place order
      </button>
      <button className={styles.browseButton} onClick={onBrowseButtonClick}>
        Browse
      </button>
      <button className={styles.ourWorkButton} onClick={onOurWorkButtonClick}>
        Our Work
      </button>
      <button
        className={styles.contactButton}
        onClick={onContactButtonClick}
      >{`Contact `}</button>
      <a className={styles.email} onClick={onEmailLinkClick}>
        Email
      </a>
      <a className={styles.linkedinA} onClick={onLinkedinClick}>
        linkedin
      </a>
      <a className={styles.youtubeA} onClick={onYoutubeLinkClick}>
        Youtube
      </a>
      <img className={styles.vectorIcon} alt="" src="../vector-3.svg" />
      <img
        className={styles.maskGroupIcon1}
        alt=""
        src="../mask-group@2x.png"
      />
      <div className={styles.editupDiv1}>Editup</div>
      <div className={styles.haveAQuery}>Have a query ?</div>
      <div className={styles.whyToWaitLetsDiscussIt}>
        <p className={styles.initiallyStartedAs}>Why to wait ?</p>
        <p className={styles.initiallyStartedAs}>Let’s discuss it now .</p>
      </div>
      <button className={styles.editupButton}>Editup</button>
      <div className={styles.editupDiv2}>Editup</div>
      <div className={styles.editupDiv3}>Editup</div>
    </div>
  );
};

export default Desktop6;
