import { FunctionComponent, useCallback, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./Desktop5.module.css";

const Desktop5: FunctionComponent = () => {
  const navigate = useNavigate();

  const onAboutButtonClick = useCallback(() => {
    navigate("/desktop-6");
  }, [navigate]);

  const onContactButtonClick = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onCheckOutButtonClick = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onCheckOutButton1Click = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onCheckOutButton2Click = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onAboutButton1Click = useCallback(() => {
    navigate("/desktop-6");
  }, [navigate]);

  const onPlaceOrderButtonClick = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onBrowseButtonClick = useCallback(() => {
    navigate("/desktop-5");
  }, [navigate]);

  const onOurWorkButtonClick = useCallback(() => {
    window.open(
      "https://drive.google.com/drive/folders/1noynemnkABw6sgfNXm8dCJLxwg2o97Q6?usp=sharing"
    );
  }, []);

  const onContactButton1Click = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onEmailLinkClick = useCallback(() => {
    window.location.href =
      "mailto:mohitkumaraptd@gmail.com?subject=Placing Order";
  }, []);

  const onLinkedinClick = useCallback(() => {
    window.location.href = "https://www.linkedin.com/in/mohit-mehta-391a4b233/";
  }, []);

  const onYoutubeLinkClick = useCallback(() => {
    window.open("https://www.youtube.com/@EditupMohitMehta/featured");
  }, []);

  useEffect(() => {
    const scrollAnimElements = document.querySelectorAll(
      "[data-animate-on-scroll]"
    );
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting || entry.intersectionRatio > 0) {
            const targetElement = entry.target;
            targetElement.classList.add(styles.animate);
            observer.unobserve(targetElement);
          }
        }
      },
      {
        threshold: 0.15,
      }
    );

    for (let i = 0; i < scrollAnimElements.length; i++) {
      observer.observe(scrollAnimElements[i]);
    }

    return () => {
      for (let i = 0; i < scrollAnimElements.length; i++) {
        observer.unobserve(scrollAnimElements[i]);
      }
    };
  }, []);

  return (
    <div className={styles.desktop5}>
      <div className={styles.editupDiv}>Editup</div>
      <button className={styles.aboutButton} onClick={onAboutButtonClick}>
        About
      </button>
      <button className={styles.contactButton} onClick={onContactButtonClick}>
        Contact
      </button>
      <img className={styles.maskGroupIcon} alt="" src="../mask-group@2x.png" />
      <img className={styles.vectorIcon} alt="" src="../vector-3.svg" />
      <div className={styles.wannaMakeAwesomeMotionGrap}>
        <p
          className={styles.wannaMakeAwesome}
        >{`Wanna make awesome motion graphics , `}</p>
        <p className={styles.introsWereHere}>intros. We’re here .</p>
      </div>
      <div className={styles.videosShortsAndReelsThat}>
        <p className={styles.wannaMakeAwesome}>
          Videos , shorts and reels that are impossible
        </p>
        <p className={styles.introsWereHere}>to ignore</p>
      </div>
      <div className={styles.postersThumbnailsCardsA}>
        <p
          className={styles.wannaMakeAwesome}
        >{`Posters , thumbnails , Cards and a lot `}</p>
        <p className={styles.introsWereHere}>more we design .</p>
      </div>
      <div className={styles.rectangleDiv} />
      <div className={styles.rectangleDiv1} />
      <div className={styles.rectangleDiv2} />
      <button
        className={styles.checkOutButton}
        onClick={onCheckOutButtonClick}
        data-animate-on-scroll
      >
        Check out
      </button>
      <button
        className={styles.checkOutButton1}
        onClick={onCheckOutButton1Click}
        data-animate-on-scroll
      >
        Check out
      </button>
      <button
        className={styles.checkOutButton2}
        onClick={onCheckOutButton2Click}
        data-animate-on-scroll
      >
        Check out
      </button>
      <img className={styles.ps1Icon} alt="" src="../ps-1@2x.png" />
      <img className={styles.pr1Icon} alt="" src="../pr-1@2x.png" />
      <img className={styles.lineIcon} alt="" src="../line-1.svg" />
      <img className={styles.lineIcon1} alt="" src="../line-1.svg" />
      <img className={styles.lineIcon2} alt="" src="../line-1.svg" />
      <img className={styles.rectangleIcon} alt="" src="../rectangle-7.svg" />
      <img className={styles.vectorIcon1} alt="" src="../vector-1.svg" />
      <div className={styles.lineDiv} />
      <div className={styles.lineDiv1} />
      <div className={styles.lineDiv2} />
      <div className={styles.lineDiv3} />
      <div className={styles.lineDiv4} />
      <div className={styles.lineDiv5} />
      <div className={styles.lineDiv6} />
      <div className={styles.lineDiv7} />
      <div className={styles.lineDiv8} />
      <div className={styles.lineDiv9} />
      <div className={styles.lineDiv10} />
      <div className={styles.lineDiv11} />
      <div className={styles.lineDiv12} />
      <div className={styles.lineDiv13} />
      <div className={styles.lineDiv14} />
      <img className={styles.ellipseIcon} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon1} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon2} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon3} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon4} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon5} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon6} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon7} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon8} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon9} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon10} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon11} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon12} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon13} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon14} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon15} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon16} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon17} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon18} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon19} alt="" src="../ellipse-57.svg" />
      <img className={styles.ellipseIcon20} alt="" src="../ellipse-57.svg" />
      <img className={styles.rectangleIcon1} alt="" src="../rectangle-81.svg" />
      <div className={styles.sliceDiv} />
      <b className={styles.motionGraphicsDesigning}>
        Motion Graphics Designing
      </b>
      <b className={styles.whatWeDo}>What we do ?</b>
      <div className={styles.bigBrandDiv}>Big Brand</div>
      <b className={styles.videoEditingB}>Video Editing</b>
      <b className={styles.makeYourBrand}>
        <p className={styles.wannaMakeAwesome}>{`Make your brand `}</p>
      </b>
      <b className={styles.theNextB}>the next</b>
      <button className={styles.getStartedButton} data-animate-on-scroll>
        Get started
      </button>
      <b className={styles.graphicsDesigningB}>Graphics Designing</b>
      <button className={styles.homeButton}>Home</button>
      <button className={styles.aboutButton1} onClick={onAboutButton1Click}>
        About
      </button>
      <button
        className={styles.placeOrderButton}
        onClick={onPlaceOrderButtonClick}
      >
        Place order
      </button>
      <button className={styles.browseButton} onClick={onBrowseButtonClick}>
        Browse
      </button>
      <button className={styles.ourWorkButton} onClick={onOurWorkButtonClick}>
        Our Work
      </button>
      <button
        className={styles.contactButton1}
        onClick={onContactButton1Click}
      >{`Contact `}</button>
      <a className={styles.email} onClick={onEmailLinkClick}>
        Email
      </a>
      <a className={styles.linkedinA} onClick={onLinkedinClick}>
        linkedin
      </a>
      <a className={styles.youtubeA} onClick={onYoutubeLinkClick}>
        Youtube
      </a>
      <img className={styles.vectorIcon2} alt="" src="../vector-3.svg" />
      <img
        className={styles.maskGroupIcon1}
        alt=""
        src="../mask-group@2x.png"
      />
      <div className={styles.editupDiv1}>Editup</div>
      <div className={styles.haveAQuery}>Have a query ?</div>
      <div className={styles.whyToWaitLetsDiscussIt}>
        <p className={styles.wannaMakeAwesome}>Why to wait ?</p>
        <p className={styles.wannaMakeAwesome}>Let’s discuss it now .</p>
      </div>
      <button className={styles.editupButton}>Editup</button>
      <div className={styles.editupDiv2}>Editup</div>
      <div className={styles.editupDiv3}>Editup</div>
    </div>
  );
};

export default Desktop5;
