import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./Desktop7.module.css";

const Desktop7: FunctionComponent = () => {
  const navigate = useNavigate();

  const onAboutButtonClick = useCallback(() => {
    navigate("/desktop-6");
  }, [navigate]);

  const onPlaceOrderButtonClick = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onBrowseButtonClick = useCallback(() => {
    navigate("/desktop-5");
  }, [navigate]);

  const onOurWorkButtonClick = useCallback(() => {
    window.open(
      "https://drive.google.com/drive/folders/1noynemnkABw6sgfNXm8dCJLxwg2o97Q6?usp=sharing"
    );
  }, []);

  const onContactButtonClick = useCallback(() => {
    navigate("/desktop-7");
  }, [navigate]);

  const onEmailLinkClick = useCallback(() => {
    window.location.href =
      "mailto:mohitkumaraptd@gmail.com?subject=Placing Order";
  }, []);

  const onLinkedinClick = useCallback(() => {
    window.location.href = "https://www.linkedin.com/in/mohit-mehta-391a4b233/";
  }, []);

  const onYoutubeLinkClick = useCallback(() => {
    window.open("https://www.youtube.com/@EditupMohitMehta/featured");
  }, []);

  return (
    <div className={styles.desktop7}>
      <div className={styles.editupDiv}>Editup</div>
      <div className={styles.aboutDiv}>About</div>
      <div className={styles.lineDiv} />
      <div className={styles.lineDiv1} />
      <div className={styles.lineDiv2} />
      <div className={styles.lineDiv3} />
      <div className={styles.lineDiv4} />
      <img className={styles.ellipseIcon} alt="" />
      <img className={styles.ellipseIcon1} alt="" />
      <img className={styles.ellipseIcon2} alt="" />
      <img className={styles.ellipseIcon3} alt="" />
      <img className={styles.ellipseIcon4} alt="" />
      <img className={styles.ellipseIcon5} alt="" />
      <img className={styles.ellipseIcon6} alt="" />
      <img className={styles.maskGroupIcon} alt="" src="../mask-group@2x.png" />
      <div className={styles.mohitkumaraptdgmailcomDiv}>
        <p className={styles.p}>{` `}</p>
        <p className={styles.mohitkumaraptdgmailcom}>
          {" "}
          mohitkumaraptd@gmail.com
        </p>
      </div>
      <img className={styles.linkedinIcon} alt="" src="../linkedin1@2x.png" />
      <img className={styles.image3Icon} alt="" src="../image-3@2x.png" />
      <b className={styles.contactUsB}>{`Contact us               `}</b>
      <div className={styles.httpswwwlinkedincominmoDiv}>
        https://www.linkedin.com/in/mohit-mehta-391a4b233/
      </div>
      <button className={styles.homeButton}>Home</button>
      <button className={styles.aboutButton} onClick={onAboutButtonClick}>
        About
      </button>
      <button
        className={styles.placeOrderButton}
        onClick={onPlaceOrderButtonClick}
      >
        Place order
      </button>
      <button className={styles.browseButton} onClick={onBrowseButtonClick}>
        Browse
      </button>
      <button className={styles.ourWorkButton} onClick={onOurWorkButtonClick}>
        Our Work
      </button>
      <button
        className={styles.contactButton}
        onClick={onContactButtonClick}
      >{`Contact `}</button>
      <a className={styles.email} onClick={onEmailLinkClick}>
        Email
      </a>
      <a className={styles.linkedinA} onClick={onLinkedinClick}>
        linkedin
      </a>
      <a className={styles.youtubeA} onClick={onYoutubeLinkClick}>
        Youtube
      </a>
      <img className={styles.vectorIcon} alt="" src="../vector-3.svg" />
      <img
        className={styles.maskGroupIcon1}
        alt=""
        src="../mask-group@2x.png"
      />
      <div className={styles.editupDiv1}>Editup</div>
      <div className={styles.haveAQuery}>Have a query ?</div>
      <div className={styles.whyToWaitLetsDiscussIt}>
        <p className={styles.p}>Why to wait ?</p>
        <p className={styles.p}>Let’s discuss it now .</p>
      </div>
      <button className={styles.editupButton}>Editup</button>
      <div className={styles.editupDiv2}>Editup</div>
      <div className={styles.editupDiv3}>Editup</div>
    </div>
  );
};

export default Desktop7;
